#include <stdint.h>

/* Record Payload Type for Bluetooth Carrier Configuration LE record */
extern const uint8_t le_oob_rec_type_field[32];
