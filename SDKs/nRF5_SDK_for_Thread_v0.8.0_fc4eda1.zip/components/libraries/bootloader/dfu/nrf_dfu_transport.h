/* Copyright (c) 2016 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */

/**@file
 *
 * @defgroup sdk_nrf_dfu_transport DFU transport
 * @{
 * @ingroup  sdk_nrf_bootloader
 * @brief Generic Device Firmware Update (DFU) transport interface.
 *
 * @details The DFU transport module defines a generic interface that must
 *          be implemented for each transport layer.
 */

#ifndef NRF_DFU_TRANSPORT_H__
#define NRF_DFU_TRANSPORT_H__

#include <stdint.h>
#include "nrf_section.h"

#ifdef __cplusplus
extern "C" {
#endif


/** @brief  Function type for initializing a DFU transport.
 *
 * @details This function initializes a DFU transport. The implementation
 *          of the function must initialize DFU mode and stay in service
 *          until either the device is reset or the DFU operation is finalized.
 *          When the DFU transport receives requests, it should call @ref nrf_dfu_req_handler_on_req for handling the requests.
 *
 * @retval  NRF_SUCCESS     If initialization was successful for the transport. Any other return code indicates that the DFU transport could not be initialized.
 */
typedef uint32_t (*nrf_dfu_init_fn_t)(void);


/** @brief  Function type for closing down a DFU transport.
 *
 * @details This function closes down a DFU transport in a gentle way.
 *
 * @retval  NRF_SUCCESS     If closing was successful for the transport. Any other return code indicates that the DFU transport could not be closed closed down.
 */
typedef uint32_t (*nrf_dfu_disconnect_fn_t)(void);


/** @brief DFU transport registration.
 *
 * @details     Every DFU transport must provide a registration of the initialization function.
 */
typedef struct
{
    nrf_dfu_init_fn_t       init_func;          /**< Registration of the init function to run to initialize a DFU transport. */
    nrf_dfu_disconnect_fn_t close_func;         /**< Registration of the close function to close down a DFU transport. */
} nrf_dfu_transport_t;


/** @brief Function for initializing all the registered DFU transports.
 *
 * @retval  NRF_SUCCESS     If all DFU transport were initialized successfully.
 *                          Any other error code indicates that at least one DFU
 *                          transport could not be initialized.
 */
uint32_t nrf_dfu_transports_init(void);

/** @brief Function for closing down all the registered DFU transports.
 *
 * @retval  NRF_SUCCESS     If all DFU transport were closed down successfully.
 *                          Any other error code indicates that at least one DFU
 *                          transport could not be closed down.
 */
uint32_t nrf_dfu_transports_close(void);


/** @brief  Macro for registering a DFU transport by using section variables.
 *
 * @details     This macro places a variable in a section named "dfu_trans", which
 *              is initialized by @ref nrf_dfu_transports_init.
 */
#define DFU_TRANSPORT_REGISTER(trans_var) NRF_SECTION_ITEM_REGISTER(dfu_trans, trans_var)


#ifdef __cplusplus
}
#endif

#endif // NRF_DFU_TRANSPORT_H__

/** @} */
